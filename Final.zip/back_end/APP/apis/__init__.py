# /APP/apis/__init__.py
secret_key = "3289jhsd@1iils9"