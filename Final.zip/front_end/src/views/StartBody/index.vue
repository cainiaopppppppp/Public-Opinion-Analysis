<!-- src/views/StartBody/index.vue -->
<script setup>
import StartBody from './StartBody.vue'
</script>

<template>
  <StartBody />
  <!-- 其他 Category.vue 的内容 -->
</template>