<!-- src/views/StartBody/StartBody.vue -->
<script setup>
// 由于这是一个简单的欢迎页面，我们不需要导入额外的组件或库

</script>

<template>
    <div class="welcome-container">
        <h1>欢迎来到我们的网站！</h1>
        <p>这里是一些介绍性的文字或者指南。</p>
    </div>
</template>

<style scoped lang="scss">
.welcome-container {
    width: 1000px;
    margin: auto;
    text-align: center; // 居中显示文字
    padding: 50px; // 添加一些内边距以美化页面
}
</style>
